$(document).ready(function(){
	
$('.circle').click(function(){
    $('.circle2').toggleClass('greencircle2');
    $('.circle3').toggleClass('yellowcircle3');
    $('.circle4').toggleClass('orangecircle4');
    $('.circle5').toggleClass('redcircle5');
    $('redcircle5').toggleClass('.circle5');
    
});
});


// $("button").click(function(){
//     $("p").toggleClass("main");
// });